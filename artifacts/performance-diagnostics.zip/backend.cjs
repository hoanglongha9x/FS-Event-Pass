"use strict";
const {performance}=require("node:perf_hooks");
module.exports=function instrument(cloud) {
  const ctx=cloud.context;
  const safeActions=new Set(["GET_EVENT_VIEW","LIST_ROSTER","LIST_EVENT_ASSIGNMENTS","SAVE_EVENT_BOOTHS",
    "SAVE_EVENT_CONFIG","TEACHER_COMPLETE","LOGIN_STUDENT","CHECK_TEACHER_SESSION","GET_EVENT_API_VERSION"]);
  const seen=new WeakSet();
  let trace=null;
  function wrap(object, name, stage, mapResult, metric) {
    if (typeof object?.[name]!=="function") return;
    const method=object[name];
    object[name]=function(...args){
      let result;
      const started=performance.now();
      try {result=method.apply(this,args);}
      finally {
        if(trace && stage){
          const data=trace[stage] ||= {ms:0,count:0};
          data.ms+=performance.now()-started;
          data.count++;
        }
        if(trace && metric) metric(args,result,trace);
      }
      return mapResult?mapResult(result,args):result;
    };
  }
  function instrumentFinder(finder) {
    wrap(finder,"findNext","sheetsSearch");
    return finder;
  }
  function instrumentRange(range, args, sheet) {
    wrap(range,"getValue","sheetsRead");
    wrap(range,"getValues","sheetsRead",null,(_,rows,t)=>{
      if(sheet==="WorkflowState")t.workflowRows+=(rows?.length||0);
      else if(sheet==="StudentRoster")t.rosterRows+=(rows?.length||0);
    });
    wrap(range,"setValues","sheetsWrite");
    wrap(range,"createTextFinder",null,instrumentFinder);
    return range;
  }
  function instrumentSheet(sheet) {
    if (!sheet || seen.has(sheet)) return sheet;
    seen.add(sheet);
    wrap(sheet,"getRange",null,(range,args)=>instrumentRange(range,args,sheet.name));
    for(const op of ["getLastRow","getMaxRows"])wrap(sheet,op,"sheetsMetadata");
    for(const op of ["appendRow","insertRowsAfter","setFrozenRows"])wrap(sheet,op,"sheetsWrite");
    return sheet;
  }
  function instrumentBook(book) {
    if(seen.has(book))return book;
    seen.add(book);
    wrap(book,"getSheetByName","sheetsMetadata",instrumentSheet);
    wrap(book,"insertSheet","sheetsWrite",instrumentSheet);
    return book;
  }
  wrap(ctx.SpreadsheetApp,"openById","sheetsOpen",instrumentBook);
  wrap(ctx.SpreadsheetApp,"flush","sheetsFlush");
  wrap(ctx.LockService,"getScriptLock",null,lock=>{wrap(lock,"waitLock","lockWait");return lock;});
  wrap(ctx,"cachedEventRows_","cacheLookup",null,(_,result,t)=>{
    if(result)t.cacheHits++;
    else t.cacheMisses++;
  });
  wrap(ctx,"cacheEventRows_","cacheRefill");
  return function profile(action, fn) {
    if(!safeActions.has(action))return {result:fn(),metric:null};
    trace={action,cacheHits:0,cacheMisses:0,workflowRows:0,rosterRows:0};
    const start=performance.now();
    try {
      const result=fn();
      trace.backendMs=performance.now()-start;
      trace.success=result?.success===true;
      if(action==="GET_EVENT_VIEW")trace.unchanged=result?.unchanged===true;
      trace.bytes=Buffer.byteLength(JSON.stringify(result));
      return {result,metric:trace};
    } finally {trace=null;}
  };
};
