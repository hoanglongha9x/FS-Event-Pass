# Bộ đo tạm cho FSchool Event Pass

Tệp traces.jsonl ghi 85 phép đo với 395 hồ sơ giả, 12 lớp, 11 gian hàng và 2.372 dòng nghiệp vụ được tạo thêm. Tệp summary.txt tổng hợp lượt đầu, trung vị năm lượt tiếp theo và lượt mô phỏng mạng chậm. Log chỉ chứa tên thao tác, thời gian, số lời gọi, số dòng và kích thước phản hồi. Các pha lồng nhau như nạp lại cache và Sheets có phần thời gian trùng nhau.

## Chạy local

Giải nén vào thư mục đo riêng. Từ gốc dự án, chạy node /đường-dẫn/run.cjs. Chạy node /đường-dẫn/summarize.cjs để tổng hợp. Runner dùng Node có Array.fromAsync, Chrome trên macOS và bản local của hai thư viện website tại /private/tmp/fsevent-pass-tailwind.js và /private/tmp/fsevent-pass-lucide.js. Các kết nối trình duyệt giới hạn ở loopback. Chạy lại sẽ ghi đè tệp traces.jsonl trong thư mục giải nén.

## Đo Apps Script thật sau khi duyệt staging

Từ gốc dự án, chạy python3 /đường-dẫn/make-staging.py để tạo bản chép .gs trong staging-copy. Dùng một dự án Web App và bảng tính thử nghiệm riêng. Trong frontend staging, trỏ GOOGLE_SCRIPT_URL vào đúng URL staging rồi nạp staging-transport.js sau script ứng dụng. Đặt Script Property FS_EVENT_PERF_TRACE=true trên dự án staging. So khớp log trình duyệt và Apps Script bằng traceId. Log backend chỉ phát sinh cho nhóm action đo và UUID hợp lệ. Kết thúc phép đo, bỏ cấu hình và bản chép gắn đo.
