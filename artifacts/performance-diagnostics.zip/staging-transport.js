// Run after the app script, only on the authorized staging frontend.
(() => {
  const actions = new Set(["GET_EVENT_VIEW", "LIST_ROSTER", "LIST_EVENT_ASSIGNMENTS",
    "SAVE_EVENT_BOOTHS", "SAVE_EVENT_CONFIG", "TEACHER_COMPLETE"]);
  const original = requestCloudAction;
  requestCloudAction = async function(action, payload, ...rest) {
    if (!actions.has(action)) return original(action, payload, ...rest);
    const traceId = crypto.randomUUID(), start = performance.now();
    try { return await original(action, {...payload, fsPerfTraceId: traceId}, ...rest); }
    finally { console.info(JSON.stringify({traceId, action, apiMs: performance.now() - start})); }
  };
})();
