"use strict";
const fs=require("node:fs"), path=require("node:path");
const data=fs.readFileSync(path.join(__dirname,"traces.jsonl"),"utf8").trim().split("\n").map(JSON.parse);
const sum=(xs, fn)=>xs.reduce((total,item)=>total+(fn(item)||0),0);
const ms=x=>x==null?"—":Number(x.toFixed(1));
const phases=["sheetsOpen","sheetsRead","sheetsSearch","sheetsMetadata","sheetsWrite","sheetsFlush"];
const median=xs=>{
  const sorted=xs.filter(x=>x!=null).sort((a,b)=>a-b);
  const middle=Math.floor(sorted.length/2);
  return sorted.length===0?null:sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2;
};
function metrics(x) {
  return {
    first:x.firstFrameMs, render:x.renderMs,
    api:x.api.length?Math.max(...x.api.map(a=>a.endMs))-Math.min(...x.api.map(a=>a.startMs)):null,
    backend:x.backend.length?sum(x.backend,a=>a.backendMs):null,
    sheets:x.backend.length?sum(x.backend,a=>sum(phases,p=>a[p]?.ms)):null,
    sync:x.api.length>1&&x.api.at(-1).action==="GET_EVENT_VIEW"?x.api.at(-1).ms:null,
    total:x.completeFrameMs,
    bytes:sum(x.backend,r=>r.bytes),
    rows:sum(x.backend,r=>r.workflowRows),
    sheetCalls:sum(x.backend,r=>sum(phases,p=>r[p]?.count)),
    icons:x.sync.renderIcons?.count||0,
    iconMs:x.sync.renderIcons?.ms||0,
    redirectMs:sum(x.resource,r=>r.redirectMs),
    bodyMs:sum(x.resource,r=>r.responseBodyMs)
  };
}
for(const label of new Set(data.map(row=>row.label))){
  const all=data.filter(row=>row.label===label), first=metrics(all[0]),
    warm=all.filter(row=>row.round>0&&row.network==="loopback").map(metrics), slow=all.find(row=>row.network==="slow_fixture");
  const fields=Object.keys(first);
  console.log(label);
  for(const [name,values] of [["first",first],["warm",Object.fromEntries(fields.map(key=>[key,median(warm.map(item=>item[key]))]))],
    ["slow",slow?metrics(slow):null]])if(values)console.log(name,JSON.stringify(Object.fromEntries(fields.map(k=>[k,ms(values[k])]))));
  console.log("actions",all[0].api.map(api=>api.action).join(" → "));
}
for(const label of ["save_with_poll_in_flight","config_click_twice","cold_unchanged_admin"]){
  const row=data.find(item=>item.label===label);
  console.log(label+" detail",JSON.stringify({api:row.api,backend:row.backend,resource:row.resource}));
}
