from pathlib import Path

root = Path.cwd()
diagnostics = Path(__file__).parent
target = diagnostics / "staging-copy"
target.mkdir(exist_ok=True)
def replace(content, old, new):
    if old not in content:
        raise RuntimeError("Staging copy no longer matches the audited code")
    return content.replace(old, new)

sources = ("Code.gs", "EventAccess.gs", "EventWorkflow.gs", "EventImages.gs")
for name in sources:
    text = (root / name).read_text()
    if name == "Code.gs":
        text = replace(text, "    action = body.action;", "    action = body.action;\n    eventPerfBegin_(action, body.fsPerfTraceId, startedAt);")
        text = replace(text, "return TEACHER_OTP_ACTIONS.includes(action) ? teacherOtpOutput_(result) : workflowOutput_(result);\n  }",
            "return TEACHER_OTP_ACTIONS.includes(action) ? teacherOtpOutput_(result) : workflowOutput_(result);\n  } finally {\n    eventPerfEnd_();\n  }")
        text = replace(text, "SpreadsheetApp.openById(id)", 'eventPerfTimed_("sheetsOpen", () => SpreadsheetApp.openById(id))')
        text = replace(text, "lock.waitLock(10000);", 'eventPerfTimed_("lockWait", () => lock.waitLock(10000));')
        text = replace(text, "sheet.getRange(2, 1, lastRow - 1, 4).getValues()",
            'eventPerfTimed_("sheetsRead", () => sheet.getRange(2, 1, lastRow - 1, 4).getValues())')
    if name == "EventAccess.gs":
        for statement in (
            "sheet.getRange(2, 1, lastRow - 1, 2).getValues()",
            "sheet.getRange(row, 2).getValue()",
        ):
            text = replace(text, statement, 'eventPerfTimed_("sheetsRead", () => ' + statement + ")")
        text = replace(text, """sheet.getRange(2, 1, lastRow - 1, 1).createTextFinder(key)
    .useRegularExpression(false).matchEntireCell(true).matchCase(true).findNext()""",
            """eventPerfTimed_("sheetsSearch", () => sheet.getRange(2, 1, lastRow - 1, 1).createTextFinder(key)
    .useRegularExpression(false).matchEntireCell(true).matchCase(true).findNext())""")
        text = replace(text, "SpreadsheetApp.flush();", 'eventPerfTimed_("sheetsFlush", () => SpreadsheetApp.flush());')
    if name == "EventWorkflow.gs":
        text = replace(text, "const found = cachedEventRows_(cache);",
            'const found = eventPerfTimed_("cacheLookup", () => cachedEventRows_(cache));')
        text = replace(text, "return cachedEventRows_(cache) || cacheEventRows_(cache);",
            'return eventPerfTimed_("cacheLookup", () => cachedEventRows_(cache)) || eventPerfTimed_("cacheRefill", () => cacheEventRows_(cache));')
    import re
    text = re.sub(r"(sheet\.(?:getRange\([^\n]+?\)\.setValues|appendRow)\([^\n]+?\));",
        r'eventPerfTimed_("sheetsWrite", () => \1);', text)
    if name == "Code.gs":
        text += "\n" + (diagnostics / "Trace.gs").read_text()
    (target / name).write_text(text)
