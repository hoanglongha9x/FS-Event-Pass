(() => {
  const syncFns = ["applyRemoteRecords","renderActiveView","renderAdminApp","showAdminTab","renderConfig","renderIcons",
    "openRosterScreen","renderRosterTable","renderRosterDetail","renderQueue","renderDashboard","renderStudentApp"];
  let active = null, depth = 0;
  function timed(name, original, self, args) {
    const span = active, first = depth++ === 0, start = performance.now();
    try { return original.apply(self,args); }
    finally {
      depth--;
      if (span) {
        const ms = performance.now() - start;
        span.sync[name] ||= {count:0,ms:0};
        span.sync[name].count++;
        span.sync[name].ms += ms;
        if (first) span.renderMs += ms;
      }
    }
  }
  for (const name of syncFns) {
    const original = eval(name);
    const wrapper = function(...args) { return timed(name,original,this,args); };
    eval(name+" = wrapper");
  }
  const originalRequest = requestCloudAction;
  requestCloudAction = async function (...args) {
    const span = active;
    if (!span) return originalRequest(...args);
    const call={action:args[0],startMs:performance.now()-span.start};
    span.api.push(call);
    try { return await originalRequest(...args); }
    finally { call.endMs=performance.now()-span.start; call.ms=call.endMs-call.startMs; }
  };
  async function measure(selectors, action, ready, measureLocal = false) {
    const span={start:performance.now(),renderMs:0,sync:{},api:[],firstMutationMs:null,firstFrameMs:null};
    active=span;
    const observer=new MutationObserver(()=>{
      if (span.firstMutationMs!==null) return;
      span.firstMutationMs=performance.now()-span.start;
      requestAnimationFrame(()=>requestAnimationFrame(()=>{
        span.firstFrameMs=performance.now()-span.start;
      }));
    });
    for (const selector of selectors) {
      const element=document.querySelector(selector);
      if (!element) throw Error("Missing diagnostic target");
      observer.observe(element,{attributes:true,attributeFilter:["open","class","aria-busy","disabled"],childList:true,subtree:true,characterData:true});
    }
    try {
      const callStart=performance.now();
      action();
      span.syncDispatchMs=performance.now()-callStart;
      if (measureLocal) span.renderMs=span.syncDispatchMs;
      while (!ready() || span.api.some(api=>api.endMs===undefined)) {
        if (performance.now()-span.start>10000) throw Error("Fixture timed out");
        await new Promise(resolve=>setTimeout(resolve,4));
      }
      span.completeMs=performance.now()-span.start;
      requestAnimationFrame(()=>requestAnimationFrame(()=>{
        span.completeFrameMs=performance.now()-span.start;
      }));
      const wait=performance.now();
      while (span.completeFrameMs===undefined && performance.now()-wait<160) {
        await new Promise(resolve=>setTimeout(resolve,4));
      }
      span.resource=performance.getEntriesByType("resource").filter(entry=>
        entry.name===GOOGLE_SCRIPT_URL && entry.startTime>=span.start).map(entry=>({
          redirectMs:entry.redirectEnd-entry.redirectStart,
          throughHeadersMs:entry.responseStart-entry.startTime,
          responseBodyMs:entry.responseEnd-entry.responseStart,
          encodedBytes:entry.encodedBodySize
        }));
      return span;
    } finally {
      observer.disconnect();
      active=null;
      stopRemoteSync();
    }
  }
  window.diagnosticMeasure=measure;
})();
