// Temporary Apps Script profiler for the staging copy only.
let eventPerfTrace_ = null;
const EVENT_PERF_ACTIONS = ["GET_EVENT_VIEW", "LIST_ROSTER", "LIST_EVENT_ASSIGNMENTS", "SAVE_EVENT_BOOTHS",
  "SAVE_EVENT_CONFIG", "TEACHER_COMPLETE"];

function eventPerfBegin_(action, traceId, startedAt) {
  if (!EVENT_PERF_ACTIONS.includes(action) || typeof traceId !== "string" ||
      !/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(traceId)) return;
  if (PropertiesService.getScriptProperties().getProperty("FS_EVENT_PERF_TRACE") !== "true") return;
  eventPerfTrace_ = { traceId: traceId, action: action, startedAt: startedAt, phases: {} };
}

function eventPerfTimed_(stage, action) {
  if (!eventPerfTrace_) return action();
  const start = Date.now();
  try { return action(); }
  finally {
    const phases = eventPerfTrace_.phases;
    const phase = phases[stage] || (phases[stage] = { elapsedMs: 0, calls: 0 });
    phase.elapsedMs += Date.now() - start;
    phase.calls++;
  }
}

function eventPerfEnd_() {
  const trace = eventPerfTrace_;
  eventPerfTrace_ = null;
  if (trace) console.log(JSON.stringify({ traceId: trace.traceId, action: trace.action,
    backendMs: Date.now() - trace.startedAt, phases: trace.phases }));
}
