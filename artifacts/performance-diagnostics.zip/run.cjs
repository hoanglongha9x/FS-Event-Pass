"use strict";
const fs=require("node:fs"), path=require("node:path"), os=require("node:os"), http=require("node:http");
const vm=require("node:vm"), crypto=require("node:crypto"), assert=require("node:assert/strict");
const {spawn}=require("node:child_process"),{setTimeout:delay}=require("node:timers/promises");
const directory=__dirname, root=process.cwd(), testPath=path.join(root,"tests/event-pass.test.cjs");
const source=fs.readFileSync(testPath,"utf8"), cut=source.indexOf('test("năm học');
const {cloud,btc,teacher,events,studentLogins,rosterRow,admin,supervisor,studentAccessVersion}=
  vm.runInNewContext(source.slice(0,cut)+"\n({...setup(395),studentLogins,rosterRow,admin,supervisor,studentAccessVersion})",{
    require:require("node:module").createRequire(testPath),__dirname:path.dirname(testPath),Buffer,console
  });
cloud.advance(Date.now()-cloud.context.Date.now());
const eventA=events[0].id, eventB=events[1].id;
const fixtureRoster=cloud.post("LIST_ROSTER",btc);
const classes=Array.from({length:12},(_,i)=>(10+Math.floor(i/4))+"A"+(i%4+1));
const profiles=Array.from({length:395},(_,i)=>({...rosterRow(i+1),className:classes[i%classes.length]}));
function ok(result){assert.equal(result.success,true,result.code);return result;}
ok(cloud.post("SAVE_ROSTER",{...btc,schoolYear:fixtureRoster.schoolYear,mode:"update",expectedRevision:fixtureRoster.revision,confirmed:true,rows:profiles}));
const originalBooths=ok(cloud.post("GET_EVENT_VIEW",btc)).records.find(record=>record.id==="booth-config").data.boothList;
const booths=[...originalBooths,...Array.from({length:5},(_,i)=>({id:"perf-"+(i+1),name:"Gian thử "+(i+1),
  location:"Phòng "+(i+1),topic:"Chủ đề thử",description:"Thông tin giả",pin:String(8100+i),icon:"sparkles",color:"blue"}))];
ok(cloud.post("SAVE_EVENT_BOOTHS",{...btc,booths}));
for(const booth of booths.slice(1,7))ok(cloud.post("SET_EVENT_ASSIGNMENT",{...btc,eventId:eventA,email:supervisor,boothId:booth.id,enabled:true}));
const rows=[];
const stampDate=new Date(cloud.context.Date.now()).toISOString();
function row(eventId, boothId, student, ticketNo, status){
  const id=eventId+"::"+boothId+"::"+student.code;
  return ["queue",id,stampDate,JSON.stringify({id,eventId,boothId,studentCode:student.code,studentName:student.name,
    className:student.className,ticketNo,status,createdAt:stampDate,completedAt:status==="completed"?stampDate:undefined})];
}
for(let i=1;i<profiles.length;i++){
  for(let j=0;j<4;j++){
    const booth=booths[(i+j)%booths.length];
    rows.push(row(eventA,booth.id,profiles[i],i+1,i%3===0?"waiting":"completed"));
    if(j<2)rows.push(row(eventB,booth.id,profiles[i],i+1,i%3===0?"waiting":"completed"));
  }
}
for(const booth of booths.slice(0,8))rows.push(row(eventA,booth.id,profiles[0],1,"waiting"));
cloud.seedRows("WorkflowState",rows);
cloud.context.withTeacherAuthLock_(()=>cloud.sheets.get("WorkflowState").insertRowsAfter(1000,3000));
cloud.cache.remove("event-pass-read-v1");
const [fixtureStudent]=studentLogins(cloud,btc,[profiles[0].code],eventA);
const profileBackend=require("./backend.cjs")(cloud);
const allowedFile=new Set(["index.html","student-pass.css","student-pass.js","event-roster.js","event-excel.js","event-images.js"]);
const redirects=new Map(), servers=[], tabs=[], measurements=[];
const injected=fs.readFileSync(path.join(directory,"browser.js"),"utf8");
let collect=null, slow=false, holdNextRead=false;
let chrome;
function server(handler){
  const s=http.createServer(handler);
  servers.push(s);
  return new Promise(resolve=>s.listen(0,"127.0.0.1",()=>resolve("http://127.0.0.1:"+s.address().port)));
}
const headers={"Access-Control-Allow-Origin":"*","Timing-Allow-Origin":"*"};
async function attach(url){
  const s=new WebSocket(url);
  tabs.push(s);
  await new Promise((resolve,reject)=>{s.addEventListener("open",resolve,{once:true});s.addEventListener("error",reject,{once:true});});
  const pending=new Map();
  let next=0;
  s.addEventListener("message",({data})=>{
    const reply=JSON.parse(data);
    if(!reply.id)return;
    const entry=pending.get(reply.id);
    if(!entry)return;
    pending.delete(reply.id);
    if(reply.error)entry.reject(Error(reply.error.message));else entry.resolve(reply.result);
  });
  const cdp=(method,params={})=>new Promise((resolve,reject)=>{
    pending.set(++next,{resolve,reject});s.send(JSON.stringify({id:next,method,params}));
  });
  const run=async expression=>{
    const reply=await cdp("Runtime.evaluate",{expression,awaitPromise:true,returnByValue:true});
    if(reply.exceptionDetails)throw Error((reply.exceptionDetails.exception?.description||reply.exceptionDetails.text).split("\n")[0]);
    return reply.result.value;
  };
  await cdp("Network.enable");
  await cdp("Network.setBlockedURLs",{urls:["*script.google.com/*","*script.googleusercontent.com/*","https://*/*"]});
  await cdp("Page.enable");
  return {cdp,run};
}
async function run(){
  const resultOrigin=await server(async(req,res)=>{
    const match=redirects.get(req.url.slice(1));
    if(!match||req.method!=="GET"){res.writeHead(404).end();return;}
    redirects.delete(req.url.slice(1));
    if(match.delayMs)await delay(match.delayMs);
    res.writeHead(200,{...headers,"Content-Type":"application/json","Cache-Control":"no-store"}).end(match.body);
  });
  const apiOrigin=await server(async(req,res)=>{
    if(req.method!=="POST"){res.writeHead(405,headers).end();return;}
    try {
      const body=JSON.parse(Buffer.concat(await Array.fromAsync(req)).toString("utf8"));
      const baseline=slow, currentLog=collect;
      if(baseline)await delay(700);
      const {result,metric}=profileBackend(body.action,()=>cloud.post(body.action,body));
      const encoded=JSON.stringify(result), key=crypto.randomUUID();
      const delayMs=(baseline?350+Buffer.byteLength(encoded)/750:0)+(holdNextRead&&body.action==="GET_EVENT_VIEW"?350:0);
      if(holdNextRead&&body.action==="GET_EVENT_VIEW")holdNextRead=false;
      if(currentLog&&metric)currentLog.push(metric);
      redirects.set(key,{body:encoded,delayMs});
      res.writeHead(302,{...headers,Location:resultOrigin+"/"+key}).end();
    } catch {res.writeHead(500,headers).end();}
  });
  const app=await server((req,res)=>{
    const name=req.url==="/"?"index.html":req.url.slice(1);
    if(name==="trace.js"){res.writeHead(200,{"Content-Type":"text/javascript"}).end(injected);return;}
    if(["lucide","tailwind"].includes(name)){
      res.writeHead(200,{"Content-Type":"text/javascript"}).end(fs.readFileSync("/private/tmp/fsevent-pass-"+name+".js"));return;
    }
    if(!allowedFile.has(name)){res.writeHead(404).end();return;}
    let body=fs.readFileSync(path.join(root,name),"utf8");
    if(name==="index.html")body=body
      .replace(/<script src="https?:[^"]+"><\/script>/g,"")
      .replace(/<link[^>]+href="https?:[^"]+"[^>]*>/g,"")
      .replace("<style>",'<script src="/tailwind"></script><script src="/lucide"></script><style>')
      .replace(/const GOOGLE_SCRIPT_URL="[^"]+"/,'const GOOGLE_SCRIPT_URL="'+apiOrigin+'/mock/exec"')
      .replace("</body>",'<script src="/trace.js"></script></body>');
    res.writeHead(200,{"Content-Type":name.endsWith(".js")?"text/javascript":name.endsWith(".css")?"text/css":"text/html; charset=utf-8"}).end(body);
  });
  const profileDir=fs.mkdtempSync(path.join(os.tmpdir(),"fsevent-current-trace-"));
  chrome=spawn("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ["--headless","--disable-gpu","--no-first-run","--disable-background-networking","--disable-background-timer-throttling",
      "--remote-debugging-port=0","--user-data-dir="+profileDir,"about:blank"],{stdio:"ignore"});
  const portFile=path.join(profileDir,"DevToolsActivePort");
  for(let i=0;i<80&&!fs.existsSync(portFile);i++)await delay(100);
  const cdpOrigin="http://127.0.0.1:"+fs.readFileSync(portFile,"utf8").split("\n")[0];
  async function client(){
    const target=await fetch(cdpOrigin+"/json/new?about:blank",{method:"PUT"}).then(res=>res.json());
    const page=await attach(target.webSocketDebuggerUrl);
    await page.cdp("Emulation.setDeviceMetricsOverride",{width:1280,height:900,deviceScaleFactor:1,mobile:false});
    await page.cdp("Page.navigate",{url:app});
    for(let i=0;i<100;i++){
      try{if(await page.run("typeof diagnosticMeasure==='function' && document.readyState==='complete' && document.getElementById('studentLoginEvent').textContent!=='Đang tải sự kiện…'"))return page;}catch{}
      await delay(40);
    }
    throw Error("Fixture page unavailable");
  }
  async function measure(page,label,round,selectors,action,ready,measureLocal=false){
    const calls=[];
    collect=calls;
    try {
      const result=await page.run("diagnosticMeasure("+JSON.stringify(selectors)+",()=>{"+action+"},()=>("+ready+"),"+measureLocal+")");
      delete result.start;
      const row={label,round,network:slow?"slow_fixture":"loopback",...result,backend:calls};
      measurements.push(row);
      fs.appendFileSync(path.join(directory,"traces.jsonl"),JSON.stringify(row)+"\n");
    } catch(error) {throw new Error(label+" round "+round+" failed: "+error.message);}
    finally {collect=null;}
  }
  fs.writeFileSync(path.join(directory,"traces.jsonl"),"");
  const adminPage=await client();
  await adminPage.run("loginAdmin("+JSON.stringify(admin)+","+JSON.stringify(btc.authToken)+",3600)");
  await adminPage.run("stopRemoteSync()");
  const tabClick=tab=>"document.querySelector('#adminApp .admin-tab[data-admin-tab="+tab+"]:not(.mobile-admin-tab)').click()";
  const waitWrite="!mutationBusy&&!remoteBusy&&!refreshQueued";
  for(let i=0;i<7;i++){
    slow=i===6;
    if(i===0)cloud.cache.remove("event-pass-read-v1");
    await adminPage.run("showAdminTab('queue')");
    await measure(adminPage,"switch_admin_tab",i,["#adminDashboardPanel"],tabClick("dashboard"),"activeAdminTab==='dashboard'");
    await measure(adminPage,"open_roster",i,["#rosterStatus","#rosterRows"],tabClick("config"),
      "!rosterRead&&document.getElementById('rosterRows').rows.length===395");
    await adminPage.run("document.getElementById('rosterSearch').value=''");
    await measure(adminPage,"search_broad",i,["#rosterRows"],
      "const n=document.getElementById('rosterSearch'); n.value='Học sinh';n.dispatchEvent(new Event('input',{bubbles:true}));",
      "document.getElementById('rosterRows').rows.length===395",true);
    await measure(adminPage,"search_narrow",i,["#rosterRows"],
      "const n=document.getElementById('rosterSearch'); n.value='395';n.dispatchEvent(new Event('input',{bubbles:true}));",
      "document.getElementById('rosterRows').rows.length===1",true);
    await measure(adminPage,"choose_student",i,["#rosterDetail"],
      "document.getElementById('rosterRows').querySelector('button').click()","Boolean(rosterStudentCode)");
    await adminPage.run("document.getElementById('rosterSearch').value='';renderRosterTable()");
    const newName="Trạm Robotics · thử "+i;
    await adminPage.run("document.getElementById('boothName-robotics').value="+JSON.stringify(newName));
    await measure(adminPage,"save_booth",i,["#remoteSyncBadge","#toastStack"],
      'document.querySelector("[onclick=\\"saveBoothSettings(\'robotics\')\\"]").click()',
      waitWrite+"&&getBooth('robotics').name==="+JSON.stringify(newName));
    const target=i%2?eventA:eventB;
    await adminPage.run("document.getElementById('activeEventSelect').value="+JSON.stringify(target));
    await measure(adminPage,"switch_event",i,["#remoteSyncBadge","#toastStack"],"document.querySelector('[onclick=\"saveEventConfig()\"]').click()",
      waitWrite+"&&activeEvent().id==="+JSON.stringify(target));
    if(!slow){
      await measure(adminPage,"poll_unchanged_admin",i,["#remoteSyncBadge"],"void pollRemote()","!remoteBusy");
    }
  }
  slow=false;
  await adminPage.run("showAdminTab('dashboard')");
  await measure(adminPage,"config_click_twice",0,["#rosterStatus","#rosterRows"],tabClick("config")+";"+tabClick("config"),
    "!rosterRead&&document.getElementById('rosterRows').rows.length===395");
  cloud.cache.remove("event-pass-read-v1");
  await measure(adminPage,"cold_unchanged_admin",0,["#remoteSyncBadge"],"void pollRemote()","!remoteBusy");
  ok(cloud.post("SAVE_EVENT_CONFIG",{...btc,config:{activeEventId:eventA,events}}));
  await adminPage.run("refreshEventNow()");
  await adminPage.run("stopRemoteSync()");
  holdNextRead=true;
  await adminPage.run("document.getElementById('boothName-robotics').value='Đổi tên khi đang poll'");
  await measure(adminPage,"save_with_poll_in_flight",0,["#remoteSyncBadge","#toastStack"],
    "void pollRemote();setTimeout(()=>saveBoothSettings('robotics'),40)",
    waitWrite+"&&getBooth('robotics').name==='Đổi tên khi đang poll'");

  const teacherPage=await client();
  await teacherPage.run("loginAdmin("+JSON.stringify(supervisor)+","+JSON.stringify(teacher.authToken)+",3600)");
  await teacherPage.run("stopRemoteSync()");
  const student=await client();
  await student.run("document.getElementById('studentCodeInput').value="+JSON.stringify(fixtureStudent.code)+
    ";document.getElementById('studentAccessInput').value="+JSON.stringify(fixtureStudent.accessCode)+";submitStudentLogin({preventDefault(){}})");
  assert.equal(await student.run("currentUser.role"),"student");
  await student.run("stopRemoteSync()");
  for(let i=0;i<7;i++){
    slow=i===6;
    await student.cdp("Page.bringToFront");
    await student.run("if(document.getElementById('studentPassDialog').open)document.getElementById('studentPassClose').click()");
    await measure(student,"open_experience_pass",i,["#studentPassDialog"],
      "document.getElementById('studentPassButton').click()","document.getElementById('studentPassDialog').open",true);
    const completedBefore=i;
    const booth=booths[i].id;
    await teacherPage.cdp("Page.bringToFront");
    await teacherPage.run("document.getElementById('teacherBoothSelect').value="+JSON.stringify(booth)+"; renderQueue()");
    await measure(teacherPage,"teacher_complete",i,["#remoteSyncBadge","#toastStack"],
      "document.getElementById('completeCurrentButton').click()",waitWrite+"&&appState.queue.some(item=>item.boothId==="+
        JSON.stringify(booth)+"&&item.ticketNo===1&&item.status==='completed')");
    await student.cdp("Page.bringToFront");
    await measure(student,"stamp_sync",i,["#studentPassBooths"],"void pollRemote()",
      "!remoteBusy&&document.querySelectorAll('#studentPassBooths .is-complete').length==="+(completedBefore+1));
    if(!slow){
      await measure(student,"poll_unchanged_student",i,["#remoteSyncBadge"],"void pollRemote()","!remoteBusy");
    }
  }
  console.log(JSON.stringify({count:measurements.length,students:profiles.length,classes:classes.length,booths:booths.length,
    workflowFixtureRows:rows.length,loopbackRounds:6,slowRounds:1}));
}
run().catch(error=>{console.error(error.stack);process.exitCode=1;}).finally(()=>{
  for(const s of tabs)s.close();
  chrome?.kill();
  for(const server of servers)server.close();
});
